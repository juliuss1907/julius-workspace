# Type Guide — Announcement

Content imported from uploaded markdown.
